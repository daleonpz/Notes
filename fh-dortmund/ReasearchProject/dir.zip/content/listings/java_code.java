/**
 * JavaDoc
 */
public class JavaBeispiel implements garNichts {

/*
 * Das ist ein plumper Kommentar
 * der �ber zwei Zeilen geht
 */
    public void macheWas throws LatexException {
        for (int i = 0; i < 666; i++) {				//Schleife durchlaufen
            System.out.println("Mache was...");
        }
    }
}